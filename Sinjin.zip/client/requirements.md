## Packages
framer-motion | For smooth page transitions and micro-interactions
lucide-react | For beautiful icons
clsx | For conditional class names
tailwind-merge | For merging tailwind classes

## Notes
The application requires an RTL layout for Arabic content.
Primary colors are Yellow and Black.
Admin credentials: Melon2026 / Aaallliii555###
